import React from 'react';
import { VisualJSON } from '../types';

interface BriefAnalysisProps {
  directions: VisualJSON[];
  onSelect: (index: number) => void;
}

const BriefAnalysis: React.FC<BriefAnalysisProps> = ({ directions, onSelect }) => {
  return (
    <div className="space-y-8 animate-fade-in">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-white mb-2">Semantic Core Analysis</h2>
        <p className="text-slate-400">The AI has reasoned 3 distinct creative directions based on your brand DNA.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {directions.map((dir, index) => (
          <div key={index} className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden hover:border-blue-500 transition-colors group flex flex-col h-full">
            <div className="p-4 border-b border-slate-700 bg-slate-900/50">
              <h3 className="text-xl font-semibold text-blue-400">Direction {String.fromCharCode(65 + index)}</h3>
              <p className="text-sm text-slate-400 capitalize">{dir.composition_style}</p>
            </div>
            
            <div className="p-6 space-y-4 text-sm flex-grow">
              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Reasoning</span>
                <p className="text-slate-300 mt-1 line-clamp-3">{dir.stable_diffusion_prompt}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Symbol</span>
                  <p className="text-slate-300">{dir.primary_symbol || 'Abstract'}</p>
                </div>
                <div>
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Negative Space</span>
                  <p className="text-slate-300">{dir.negative_space_subject || 'None'}</p>
                </div>
              </div>

              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Palette</span>
                <div className="flex gap-2 mt-1">
                  {dir.color_hex_codes.map((color, i) => (
                    <div key={i} className="w-8 h-8 rounded-full border border-white/10 shadow-sm" style={{ backgroundColor: color }} title={color}></div>
                  ))}
                </div>
              </div>

              <div>
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Typography</span>
                <div className="flex gap-2 mt-1">
                  <span className="bg-slate-700 px-2 py-1 rounded text-xs text-slate-300">{dir.typography_guidance.primary_font_category}</span>
                  <span className="bg-slate-700 px-2 py-1 rounded text-xs text-slate-300">{dir.typography_guidance.weight_suggestion}</span>
                </div>
              </div>
              
              <div className="pt-2">
                 <div className="flex justify-between items-center text-xs text-emerald-400">
                    <span>Semantic Match</span>
                    <span>{Math.round(dir.metadata.confidence_scores.semantic_match * 100)}%</span>
                 </div>
                 <div className="w-full bg-slate-700 h-1.5 rounded-full mt-1">
                    <div className="bg-emerald-500 h-1.5 rounded-full" style={{ width: `${dir.metadata.confidence_scores.semantic_match * 100}%` }}></div>
                 </div>
              </div>
            </div>

            <div className="p-4 bg-slate-900/30 mt-auto">
              <button
                onClick={() => onSelect(index)}
                className="w-full py-2 bg-slate-700 hover:bg-blue-600 text-white rounded-lg transition-colors font-medium border border-slate-600 hover:border-blue-500"
              >
                Generate Concepts
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default BriefAnalysis;
