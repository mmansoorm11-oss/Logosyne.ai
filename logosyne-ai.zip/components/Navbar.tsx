import React from 'react';
import { AppStage } from '../types';

interface NavbarProps {
  currentStage: AppStage;
}

const Navbar: React.FC<NavbarProps> = ({ currentStage }) => {
  const steps = [
    { id: 'onboarding', label: 'Brief' },
    { id: 'analysis', label: 'Semantic Core' },
    { id: 'generation', label: 'Synthesis Core' },
    { id: 'studio', label: 'Vector Core' },
  ];

  return (
    <nav className="border-b border-slate-800 bg-slate-900/80 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
            <span className="font-bold text-xl tracking-tight text-white">Logosyne <span className="text-blue-500">AI</span></span>
          </div>
          
          <div className="hidden md:block">
            <div className="flex items-baseline space-x-4">
              {steps.map((step, idx) => {
                 const isActive = step.id === currentStage;
                 const isCompleted = steps.findIndex(s => s.id === currentStage) > idx;
                 
                 return (
                  <div key={step.id} className="flex items-center">
                     <span className={`text-sm font-medium transition-colors ${isActive ? 'text-blue-400' : isCompleted ? 'text-emerald-500' : 'text-slate-600'}`}>
                       {step.label}
                     </span>
                     {idx < steps.length - 1 && <span className="mx-2 text-slate-700">/</span>}
                  </div>
                 )
              })}
            </div>
          </div>

          <div>
            <span className="bg-slate-800 text-slate-300 px-3 py-1 rounded-full text-xs font-mono border border-slate-700">Beta v0.9</span>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
