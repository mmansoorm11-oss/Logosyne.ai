import React, { useState } from 'react';
import { BrandBrief } from '../types';

interface OnboardingProps {
  onComplete: (brief: BrandBrief) => void;
  isLoading: boolean;
}

const Onboarding: React.FC<OnboardingProps> = ({ onComplete, isLoading }) => {
  const [brief, setBrief] = useState<BrandBrief>({
    brandName: '',
    slogan: '',
    industry: '',
    adjectives: '',
    admiredBrands: [],
    additionalInfo: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete(brief);
  };

  const handleAdmiredBrandAdd = (brand: string) => {
    if (brand && brief.admiredBrands.length < 3) {
      setBrief(prev => ({ ...prev, admiredBrands: [...prev.admiredBrands, brand] }));
    }
  };

  return (
    <div className="max-w-3xl mx-auto p-6 bg-slate-800 rounded-xl shadow-2xl border border-slate-700">
      <div className="mb-8 text-center">
        <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-emerald-400">
          Project Identity
        </h2>
        <p className="text-slate-400 mt-2">Initialize the Semantic Core with your brand DNA.</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Brand Name</label>
            <input
              required
              type="text"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none transition"
              placeholder="e.g. BlueHarbor"
              value={brief.brandName}
              onChange={(e) => setBrief({ ...brief, brandName: e.target.value })}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-1">Industry</label>
            <input
              required
              type="text"
              className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none transition"
              placeholder="e.g. Fintech"
              value={brief.industry}
              onChange={(e) => setBrief({ ...brief, industry: e.target.value })}
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1">Slogan (Optional)</label>
          <input
            type="text"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none transition"
            placeholder="e.g. Secure your future"
            value={brief.slogan}
            onChange={(e) => setBrief({ ...brief, slogan: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1">Adjectives (Tone)</label>
          <input
            required
            type="text"
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none transition"
            placeholder="e.g. Trustworthy, Modern, Global, Minimalist"
            value={brief.adjectives}
            onChange={(e) => setBrief({ ...brief, adjectives: e.target.value })}
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1">Admired Brands (Max 3)</label>
          <div className="flex gap-2 mb-2">
            <input
              id="admired-input"
              type="text"
              className="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
              placeholder="Type and press Enter"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAdmiredBrandAdd(e.currentTarget.value);
                  e.currentTarget.value = '';
                }
              }}
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {brief.admiredBrands.map((b, i) => (
              <span key={i} className="bg-blue-900/50 text-blue-200 px-3 py-1 rounded-full text-sm border border-blue-800 flex items-center gap-2">
                {b}
                <button
                  type="button"
                  onClick={() => setBrief(prev => ({ ...prev, admiredBrands: prev.admiredBrands.filter((_, idx) => idx !== i) }))}
                  className="hover:text-white"
                >
                  &times;
                </button>
              </span>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-slate-300 mb-1">Additional Context</label>
          <textarea
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none h-24"
            placeholder="Describe your vision, target audience details, or specific imagery..."
            value={brief.additionalInfo}
            onChange={(e) => setBrief({ ...brief, additionalInfo: e.target.value })}
          />
        </div>

        <button
          type="submit"
          disabled={isLoading}
          className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-bold py-3 rounded-lg shadow-lg transform transition active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? (
            <span className="flex items-center justify-center gap-2">
              <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Analyzing DNA...
            </span>
          ) : (
            "Initialize Semantic Core"
          )}
        </button>
      </form>
    </div>
  );
};

export default Onboarding;
