import React, { useState } from 'react';
import VectorCanvas from './VectorCanvas';
import { ChatMessage } from '../types';
import { sendChatMessage } from '../services/geminiService';

interface StudioProps {
  svgContent: string;
  onExport: () => void;
}

const Studio: React.FC<StudioProps> = ({ svgContent, onExport }) => {
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    { id: '1', role: 'assistant', content: 'I am the Logosyne Vector Assistant. How would you like to refine this geometry?', timestamp: Date.now() }
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [isSending, setIsSending] = useState(false);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputMessage.trim() || isSending) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: inputMessage,
      timestamp: Date.now()
    };

    setChatHistory(prev => [...prev, userMsg]);
    setInputMessage('');
    setIsSending(true);

    const responseText = await sendChatMessage(userMsg.content, [...chatHistory, userMsg]);
    
    const botMsg: ChatMessage = {
      id: (Date.now() + 1).toString(),
      role: 'assistant',
      content: responseText,
      timestamp: Date.now()
    };

    setChatHistory(prev => [...prev, botMsg]);
    setIsSending(false);
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-140px)] gap-4 animate-fade-in">
      
      {/* Left Panel: Layers & Properties (Visual Mockup) */}
      <div className="w-full lg:w-64 bg-slate-800 rounded-xl border border-slate-700 flex flex-col overflow-hidden">
        <div className="p-4 border-b border-slate-700 font-semibold text-slate-300">Layers</div>
        <div className="flex-1 p-2 space-y-1 overflow-y-auto">
          {['Symbol Group', '↳ Path 1 (Shield)', '↳ Path 2 (Anchor)', 'Typography Group', '↳ Text (BlueHarbor)'].map((layer, i) => (
             <div key={i} className="px-3 py-2 rounded hover:bg-slate-700 text-sm text-slate-400 cursor-pointer flex items-center gap-2">
                <svg className="w-4 h-4 text-slate-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                {layer}
             </div>
          ))}
        </div>
        <div className="p-4 border-t border-slate-700 bg-slate-900/50">
           <div className="text-xs text-slate-500 uppercase font-bold mb-2">Properties</div>
           <div className="grid grid-cols-2 gap-2">
              <div className="bg-slate-800 h-8 rounded border border-slate-600 flex items-center justify-center text-xs text-slate-400">Fill</div>
              <div className="bg-slate-800 h-8 rounded border border-slate-600 flex items-center justify-center text-xs text-slate-400">Stroke</div>
           </div>
        </div>
      </div>

      {/* Center: Canvas */}
      <div className="flex-1 flex flex-col">
        <VectorCanvas svgContent={svgContent} />
      </div>

      {/* Right: Assistant & Actions */}
      <div className="w-full lg:w-80 flex flex-col gap-4">
        
        {/* Actions */}
        <div className="bg-slate-800 rounded-xl border border-slate-700 p-4">
            <button onClick={onExport} className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-2 rounded-lg shadow-lg mb-3">
               Export Brand Kit
            </button>
            <div className="grid grid-cols-2 gap-2">
               <button className="py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm rounded border border-slate-600">Palette Swap</button>
               <button className="py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 text-sm rounded border border-slate-600">Font Pair</button>
            </div>
        </div>

        {/* Chat Interface */}
        <div className="flex-1 bg-slate-800 rounded-xl border border-slate-700 flex flex-col overflow-hidden">
           <div className="p-3 border-b border-slate-700 bg-slate-900/50 text-sm font-medium text-slate-300">
             Talk to Designer (LLM)
           </div>
           
           <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {chatHistory.map((msg) => (
                <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                   <div className={`max-w-[85%] rounded-lg px-3 py-2 text-sm ${
                      msg.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-700 text-slate-200'
                   }`}>
                      {msg.content}
                   </div>
                </div>
              ))}
              {isSending && <div className="text-xs text-slate-500 animate-pulse">Assistant is typing...</div>}
           </div>

           <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-700 bg-slate-900/50 flex gap-2">
              <input
                className="flex-1 bg-slate-800 border border-slate-600 rounded px-3 py-1.5 text-sm text-white focus:outline-none focus:border-blue-500"
                placeholder="Make the icon bolder..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
              />
              <button type="submit" disabled={isSending} className="text-blue-400 hover:text-blue-300">
                 <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
              </button>
           </form>
        </div>
      </div>
    </div>
  );
};

export default Studio;
