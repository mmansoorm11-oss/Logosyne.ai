import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Onboarding from './components/Onboarding';
import BriefAnalysis from './components/BriefAnalysis';
import GenerationGrid from './components/GenerationGrid';
import Studio from './components/Studio';
import { AppStage, BrandBrief, ProjectState } from './types';
import { generateVisualDirections } from './services/geminiService';
import { api } from './services/apiService';

const App: React.FC = () => {
  const [stage, setStage] = useState<AppStage>('onboarding');
  const [isLoading, setIsLoading] = useState(false);
  const [project, setProject] = useState<ProjectState>({
    id: '',
    brief: {} as BrandBrief,
    visualDirections: [],
    selectedDirectionIndex: null,
    concepts: [],
    selectedConceptId: null,
    vectorSvg: null
  });

  // Step 1: Onboarding -> Semantic Core
  const handleBriefSubmit = async (brief: BrandBrief) => {
    setIsLoading(true);
    try {
      const directions = await generateVisualDirections(brief);
      setProject(prev => ({
        ...prev,
        brief,
        visualDirections: directions
      }));
      setStage('analysis');
    } catch (error) {
      console.error("Analysis failed", error);
      alert("Failed to analyze brief. Please check API key configuration.");
    } finally {
      setIsLoading(false);
    }
  };

  // Step 2: Analysis -> Synthesis Core
  const handleDirectionSelect = async (index: number) => {
    setProject(prev => ({ ...prev, selectedDirectionIndex: index }));
    setStage('generation');
    
    // Trigger Concept Generation Mock
    const direction = project.visualDirections[index];
    const newConcepts = await api.generateConcepts(direction, `dir-${index}`);
    
    setProject(prev => ({ ...prev, concepts: newConcepts }));
  };

  // Step 3: Synthesis -> Vector Core
  const handleConceptSelect = async (conceptId: string) => {
    setIsLoading(true);
    try {
       const result = await api.vectorize(conceptId);
       setProject(prev => ({ 
         ...prev, 
         selectedConceptId: conceptId,
         vectorSvg: result.rawSvg
       }));
       setStage('studio');
    } finally {
      setIsLoading(false);
    }
  };

  // Step 4: Export
  const handleExport = () => {
    // Mock export
    alert("Downloading logosyne_brand_kit.zip...");
  };

  return (
    <div className="min-h-screen bg-slate-900 text-slate-200 font-sans selection:bg-blue-500 selection:text-white">
      <Navbar currentStage={stage} />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {isLoading && stage === 'studio' && (
          <div className="fixed inset-0 bg-slate-900/90 z-50 flex items-center justify-center flex-col">
             <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mb-4"></div>
             <div className="text-xl font-bold text-white">Vector Core Processing</div>
             <div className="text-slate-400 mt-2">Tracing paths • Optimizing nodes • Grouping layers</div>
          </div>
        )}

        {stage === 'onboarding' && (
          <Onboarding onComplete={handleBriefSubmit} isLoading={isLoading} />
        )}

        {stage === 'analysis' && (
          <BriefAnalysis 
            directions={project.visualDirections} 
            onSelect={handleDirectionSelect} 
          />
        )}

        {stage === 'generation' && (
          <GenerationGrid 
             concepts={project.concepts} 
             onConceptSelect={handleConceptSelect}
             isGenerating={project.concepts.length === 0}
          />
        )}

        {stage === 'studio' && project.vectorSvg && (
          <Studio 
            svgContent={project.vectorSvg} 
            onExport={handleExport} 
          />
        )}
      </main>
    </div>
  );
};

export default App;
