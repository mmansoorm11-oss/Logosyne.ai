import { GenerationConcept, VisualJSON } from '../types';

// Simulate API Latency
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const api = {
  // POST /api/v1/generate-concepts
  generateConcepts: async (visualJson: VisualJSON, directionId: string): Promise<GenerationConcept[]> => {
    await delay(2500); // Simulate diffusion time
    
    // In a real app, this calls the backend which uses SDXL/Flux
    // Here we generate mock concepts using placeholders
    return Array.from({ length: 9 }).map((_, i) => ({
      id: `${directionId}-concept-${i}`,
      visualJson: visualJson,
      imageUrl: `https://picsum.photos/seed/${directionId}${i}/512/512`, // Placeholder
      status: 'completed'
    }));
  },

  // POST /api/v1/vectorize
  vectorize: async (conceptId: string): Promise<{ svgUrl: string, metadata: any, rawSvg: string }> => {
    await delay(3000); // Simulate Neural Vectorization
    
    // Return a sample SVG string
    const sampleSvg = `
      <svg viewBox="0 0 512 512" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" style="stop-color:#3b82f6;stop-opacity:1" />
            <stop offset="100%" style="stop-color:#1d4ed8;stop-opacity:1" />
          </linearGradient>
        </defs>
        <circle cx="256" cy="256" r="200" fill="url(#grad1)" />
        <path d="M150 256 L256 150 L362 256 L256 362 Z" fill="#ffffff" />
        <text x="50%" y="480" text-anchor="middle" fill="#e2e8f0" font-family="sans-serif" font-size="40">Logosyne</text>
      </svg>
    `;

    return {
      svgUrl: `data:image/svg+xml;base64,${btoa(sampleSvg)}`,
      metadata: { node_count: 12, groups: ['shape', 'text'] },
      rawSvg: sampleSvg
    };
  },

  // GET /api/v1/competitor-check
  checkPlagiarism: async (conceptId: string) => {
    await delay(1000);
    return {
      similarity_score: 0.12,
      closest_matches: [],
      advice: "Original design detected."
    };
  }
};
