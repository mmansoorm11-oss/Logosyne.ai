import { GoogleGenAI, Type, Schema } from "@google/genai";
import { BrandBrief, VisualJSON, ChatMessage } from '../types';

// Initialize Gemini Client
// In a real scenario, this would be proxied through the backend to protect the key.
const apiKey = process.env.API_KEY || ''; 
const ai = new GoogleGenAI({ apiKey });

// Schema for Visual JSON strict output
const visualJsonSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    brand_name: { type: Type.STRING },
    slogan: { type: Type.STRING, nullable: true },
    industry: { type: Type.STRING },
    audience: { type: Type.ARRAY, items: { type: Type.STRING } },
    keywords: { type: Type.ARRAY, items: { type: Type.STRING } },
    primary_symbol: { type: Type.STRING, nullable: true },
    composition_style: { type: Type.STRING },
    negative_space_subject: { type: Type.STRING, nullable: true },
    color_hex_codes: { type: Type.ARRAY, items: { type: Type.STRING } },
    typography_guidance: {
      type: Type.OBJECT,
      properties: {
        primary_font_category: { type: Type.STRING, enum: ["serif", "sans-serif", "display", "mono"] },
        weight_suggestion: { type: Type.STRING, enum: ["light", "regular", "bold"] },
      },
      required: ["primary_font_category", "weight_suggestion"]
    },
    visual_constraints: {
      type: Type.OBJECT,
      properties: {
        must_include: { type: Type.ARRAY, items: { type: Type.STRING } },
        must_avoid: { type: Type.ARRAY, items: { type: Type.STRING } },
      },
      required: ["must_include", "must_avoid"]
    },
    stable_diffusion_prompt: { type: Type.STRING },
    controlnet_constraints: {
      type: Type.OBJECT,
      properties: {
        shape_mask_hint: { type: Type.STRING },
        aspect_ratio: { type: Type.STRING, enum: ["square", "horizontal", "vertical"] },
      },
      required: ["shape_mask_hint", "aspect_ratio"]
    },
    metadata: {
      type: Type.OBJECT,
      properties: {
        confidence_scores: {
          type: Type.OBJECT,
          properties: {
            semantic_match: { type: Type.NUMBER },
          },
          required: ["semantic_match"]
        }
      },
      required: ["confidence_scores"]
    }
  },
  required: [
    "brand_name", "industry", "audience", "keywords", "composition_style", 
    "color_hex_codes", "typography_guidance", "visual_constraints", 
    "stable_diffusion_prompt", "controlnet_constraints", "metadata"
  ]
};

export const generateVisualDirections = async (brief: BrandBrief): Promise<VisualJSON[]> => {
  if (!apiKey) {
    console.error("API Key missing");
    return mockVisualResponse(brief);
  }

  try {
    const prompt = `
      Act as the 'Semantic Core' (Creative Director) for Logosyne AI.
      Analyze the following brand brief and generate 3 distinct Creative Directions (A, B, and C).
      
      Brief:
      Brand Name: ${brief.brandName}
      Slogan: ${brief.slogan}
      Industry: ${brief.industry}
      Adjectives: ${brief.adjectives}
      Admired Brands: ${brief.admiredBrands.join(', ')}
      Additional Info: ${brief.additionalInfo}

      Output strict JSON format.
    `;

    const model = 'gemini-2.5-flash';
    
    // We request 3 candidates or loop 3 times. For simplicity in this demo, we'll ask for an array in a wrapping schema or just make 3 calls parallel/sequence.
    // To adhere strictly to the "exact schema" per object, let's wrap it in an array for the response.
    
    const arraySchema: Schema = {
      type: Type.ARRAY,
      items: visualJsonSchema
    };

    const response = await ai.models.generateContent({
      model,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: arraySchema,
        systemInstruction: "You are Logosyne AI's Semantic Core. You convert brand briefs into visual reasoning tokens."
      }
    });

    if (response.text) {
      return JSON.parse(response.text) as VisualJSON[];
    }
    throw new Error("No text response from Gemini");

  } catch (error) {
    console.error("Gemini API Error:", error);
    return mockVisualResponse(brief);
  }
};

export const chatWithDesigner = async (history: ChatMessage[], currentSvg: string): Promise<string> => {
   if (!apiKey) return "I'm sorry, I cannot connect to the design brain right now (Missing API Key).";

   try {
     const messages = history.map(h => ({
       role: h.role === 'assistant' ? 'model' : 'user',
       parts: [{ text: h.content }]
     }));

     // Add context about current SVG state
     const systemContext = `
      You are the Logosyne Studio Assistant. You help users refine their logos.
      Current Vector State (Simplified Representation): ${currentSvg.substring(0, 500)}...
      
      If the user asks to change color, shape, or typography, acknowledge it and suggest how the 'Vector Core' would handle it.
      Keep responses concise and helpful.
     `;

     const model = 'gemini-2.5-flash';
     const chat = ai.chats.create({
        model,
        history: messages as any,
        config: {
          systemInstruction: systemContext
        }
     });

     const result = await chat.sendMessage({ message: "Please assist with the design." }); 
     // In a real app, the user's *new* message would be passed here. 
     // However, the architecture of chat.sendMessage expects the new message. 
     // We assume the caller handles history state and passes the *latest* message. 
     // For this simulated function, we'll assume the last message in history is the trigger.
     
     // Correcting usage: The caller should pass the NEW message string, not the whole history for the call.
     // Refactoring signature to take newMessage string.
     return result.text || "";
   } catch (e) {
     return "Thinking...";
   }
};

export const sendChatMessage = async (newMessage: string, history: ChatMessage[]): Promise<string> => {
   if (!apiKey) return "Demo Mode: API Key missing.";
   
   try {
      const model = 'gemini-2.5-flash';
      const chatHistory = history.map(h => ({
        role: h.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: h.content }]
      }));

      const chat = ai.chats.create({
        model,
        history: chatHistory as any,
        config: { systemInstruction: "You are the Logosyne Design Assistant. Concise, professional, creative." }
      });
      
      const result = await chat.sendMessage({ message: newMessage });
      return result.text || "I didn't catch that.";
   } catch (error) {
     console.error(error);
     return "Connection error.";
   }
}


// Fallback mock data if API fails or key is missing
const mockVisualResponse = (brief: BrandBrief): VisualJSON[] => {
  const mock1: VisualJSON = {
    brand_name: brief.brandName,
    slogan: brief.slogan,
    industry: brief.industry,
    audience: ["General"],
    keywords: ["Modern", "Clean", "Tech"],
    primary_symbol: "Abstract shape",
    composition_style: "Minimalist Geometry",
    negative_space_subject: null,
    color_hex_codes: ["#3b82f6", "#1e293b", "#ffffff"],
    typography_guidance: { primary_font_category: "sans-serif", weight_suggestion: "bold" },
    visual_constraints: { must_include: ["blue"], must_avoid: ["complex details"] },
    stable_diffusion_prompt: "minimalist tech logo, blue vector gradient",
    controlnet_constraints: { shape_mask_hint: "circle", aspect_ratio: "square" },
    metadata: { confidence_scores: { semantic_match: 0.95 } }
  };

  const mock2: VisualJSON = {
    brand_name: brief.brandName,
    slogan: brief.slogan,
    industry: brief.industry,
    audience: ["Youth"],
    keywords: ["Bold", "Dynamic"],
    primary_symbol: "Lettermark",
    composition_style: "Typographic",
    negative_space_subject: "Arrow",
    color_hex_codes: ["#ef4444", "#000000"],
    typography_guidance: { primary_font_category: "display", weight_suggestion: "regular" },
    visual_constraints: { must_include: ["red"], must_avoid: ["serifs"] },
    stable_diffusion_prompt: "bold typographic logo, negative space arrow",
    controlnet_constraints: { shape_mask_hint: "text", aspect_ratio: "horizontal" },
    metadata: { confidence_scores: { semantic_match: 0.88 } }
  };

  return [mock1, mock1, mock2];
};
