// Exact Visual JSON Schema from prompt
export interface VisualJSON {
  brand_name: string;
  slogan: string | null;
  industry: string;
  audience: string[];
  keywords: string[];
  primary_symbol: string | null;
  composition_style: string;
  negative_space_subject: string | null;
  color_hex_codes: string[];
  typography_guidance: {
    primary_font_category: "serif" | "sans-serif" | "display" | "mono";
    weight_suggestion: "light" | "regular" | "bold";
  };
  visual_constraints: {
    must_include: string[];
    must_avoid: string[];
  };
  stable_diffusion_prompt: string;
  controlnet_constraints: {
    shape_mask_hint: string;
    aspect_ratio: "square" | "horizontal" | "vertical";
  };
  metadata: {
    confidence_scores: {
      semantic_match: number;
    };
  };
}

// App Application State Types
export type AppStage = 'onboarding' | 'analysis' | 'generation' | 'studio';

export interface BrandBrief {
  brandName: string;
  slogan: string;
  industry: string;
  adjectives: string;
  admiredBrands: string[];
  additionalInfo: string;
}

export interface GenerationConcept {
  id: string;
  visualJson: VisualJSON;
  imageUrl: string; // Placeholder for raster
  status: 'generating' | 'completed';
}

export interface ProjectState {
  id: string;
  brief: BrandBrief;
  visualDirections: VisualJSON[]; // A/B/C directions
  selectedDirectionIndex: number | null;
  concepts: GenerationConcept[];
  selectedConceptId: string | null;
  vectorSvg: string | null; // The editable SVG content
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
}
